Tiny Mind binding starter pack

Drop this ZIP onto the Models bay in the rebuilt tiny-mind-mega.html.
It includes the original trainee, step-400 demonstration model, step-600 maximum-binding model, tokenizer, and replay corpus.

Drop binding-arc-latest.zip separately for the time machine, or use tiny-mind-binding-test-pack.zip for a single-drop test.
The balanced storybook is supplied separately as binding-stories.json for retraining experiments.
