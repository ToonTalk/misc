# Tiny Mind app-improvement task

## Goal
Turn the balanced-character arc into a clear lesson about the difference between:

1. becoming familiar with a story distribution,
2. binding facts to particular names,
3. retaining ordinary storytelling ability, and
4. following new local context rather than rigid learned defaults.

Do not retrain models in this task. Use the supplied arc and evaluation results.

## Critical correction
The existing evaluator copied step 60 as `stories260K-binding.bin`. That choice is unsuitable for the app because it has only 25% direct accuracy and 33.3% specificity. Replace the single opaque recommendation with three named profiles:

- `held-loss minimum`: step 60
- `binding demonstration`: step 400 — default for Microscope/Treasure Hunt
- `maximum binding`: step 600

The default shipped binding model should be step 400. Do not delete step 600 from the arc.

## Required source changes

### 1. Nursery time machine
Likely files: `nursery/index.html`, `src/scrubber.js`, `nursery/guide.js`.

When a snapshot has a `binding` object, display:

- character-answer accuracy (`directAccuracy`)
- name specificity (`specificityAccuracy`)
- cross-name leakage (`meanLeakageRatio`)
- binding score
- ordinary-story surprise and its increase from step 0

Add a stage badge derived from metrics, not hardcoded step numbers:

- specificity < 0.5: `mixing the characters`
- specificity >= 0.5 and direct < 0.6: `names beginning to matter`
- specificity >= 0.8 and direct >= 0.6: `character facts separating`
- specificity >= 0.95 and direct >= 0.8: `strong character binding`

Add an additional warning when base loss has increased by at least 0.25 from the first snapshot: `ordinary storytelling is being damaged`.

Explain the step-60 result explicitly: held-out story loss can improve before the model knows which character owns which fact.

Add `arcC` to the kid-label table as `a mind learning which facts belong to which character`.

### 2. Dynamic Treasure Hunt quests
Likely files: `hunt/index.html`, `hunt/worker.js`, `hunt/guide.js`.

When the loaded arc manifest includes `characters`, generate quest presets from that table instead of showing only hardcoded Zog quests. Keep a fallback for arbitrary models.

Suggested default quests for step 400:

- `Zog is a small` → ` dragon`
- `Mip likes to eat` → ` apples`
- `Bex's home is by the` → ` cave`
- `Nia likes to eat` → ` berries`

Avoid making Zog→clouds the sole flagship quest because it is name-specific but not the highest-scoring food at step 400 or 600.

### 3. Better name controls
For arcC, use the other manifest characters as controls: Zog, Mip, Bex, Nia. Do not default to Max/Lily/Tom when matched characters are available.

Use per-token log-probability or geometric-mean probability for comparisons when answer lengths differ. Report:

- target answer score for the intended name
- best score under another name
- margin and leakage ratio

Replace the current binary wording with:

- `name-specific` when intended name ranks first and leakage ratio <= 0.8
- `partly name-specific` when intended name ranks first but leakage is > 0.8, or margin is small
- `not name-specific yet` when another name ranks first

### 4. Honest ablation language
Replace `PROVED` and “the fact lives here” with evidence-calibrated wording:

- `strong causal contributor`
- `general-purpose contributor`
- `possible suppressor`
- `little measured effect`

A component is not a selective contributor merely because target probability falls. Test at least three unrelated control completions and compare target damage with median control damage.

Suggested classification:

- target ratio < 0.5 and target damage >= 2× median control damage: selective/strong causal contributor
- target ratio < 0.5 but control damage is similar: general-purpose contributor
- target ratio > 1.15: possible suppressor
- otherwise: little or modest measured effect

Update the guide copy and scoreboard accordingly. Count “tests run” and “selective contributors,” not “proofs.”

### 5. Improve clue generation
The built-in detective currently overweights attention to the name and name-piece neurons. Include:

- top heads attending to the character name
- neurons contrasting on name pieces
- neurons active at the prediction boundary (`boundaryNeurons` if already emitted)

Add a `screen candidates` action that runs the small causal/control test automatically and ranks candidates by selectivity. Preserve the distinction between visual clues and causal measurements.

### 6. Evaluation and model selection tools
Replace the current hard +0.15 base-loss filter. Output three profiles rather than one recommendation. A proposed implementation is included as `tools/select-binding-profiles.js`.

Copy or package:

- step 400 as `models/stories260K-binding.bin`
- step 600 as `models/stories260K-binding-max.bin`

Do not label step 60 as the recommended binding model.

### 7. Add language-quality diagnostics
Keep repeated four-grams, but also add:

- wrong-character name intrusions
- wrong attribute intrusions
- expected character-name retention
- malformed-name prefix detection such as `Zoggy`, `Mipvie`, `Bexi`, `Niasha`
- optional base-loss drift as the primary language-retention signal

Do not pretend these heuristics are a complete measure of prose quality.

## Acceptance tests

1. Dropping `binding-arc.zip` still loads all 11 snapshots with no console errors.
2. Step 60 is visibly labelled as low held-out loss but weak binding.
3. Step 400 is labelled as the recommended investigation point.
4. Step 600 is labelled as maximum binding with stronger forgetting/rigidity.
5. The time machine displays direct and specificity metrics from the manifest.
6. Treasure Hunt offers all four characters when arcC is active.
7. Name controls use the other three trained characters.
8. No user-facing text says an ablation “proved where a fact lives.”
9. Ablation verdicts include unrelated control prompts.
10. Build and existing tests pass; run `node tools/build-release.js` and browser-smoke-test the mega release.

## Return to Ken
Provide:

- a ZIP or PR containing source changes
- the rebuilt mega HTML
- the updated binding model bundle
- a concise test report
- screenshots of step 60, step 400, and an ablation verdict if convenient
