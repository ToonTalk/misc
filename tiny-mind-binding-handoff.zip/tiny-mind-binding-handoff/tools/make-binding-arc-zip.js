// Package the balanced binding arc and the analysis files.
// Usage: node tools/make-binding-arc-zip.js [arc/binding]
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeZip } from './zip.js';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const arcRel = process.argv[2] ?? 'arc/binding';
const arcDir = join(ROOT, arcRel);
const dist = join(ROOT, 'dist');
await mkdir(dist, { recursive: true });
const enc = new TextEncoder();

const manifest = JSON.parse(await readFile(join(arcDir, 'arc-manifest.json'), 'utf8'));
const arcEntries = [{ name: 'arc-manifest.json', data: enc.encode(JSON.stringify(manifest, null, 1)) }];
for (const s of manifest.snapshots) {
  arcEntries.push({ name: s.file, data: new Uint8Array(await readFile(join(arcDir, s.file))) });
}
const arcZip = makeZip(arcEntries);
await writeFile(join(dist, 'binding-arc.zip'), arcZip);
console.log(`dist/binding-arc.zip: ${manifest.snapshots.length} snapshots, ${(arcZip.length / 1e6).toFixed(1)} MB`);

const resultFiles = [
  [join(arcDir, 'arc-manifest.json'), 'arc-manifest.json'],
  [join(arcDir, 'binding-evaluation.json'), 'binding-evaluation.json'],
  [join(arcDir, 'binding-evaluation.md'), 'binding-evaluation.md'],
  [join(arcDir, 'recommended-checkpoint.json'), 'recommended-checkpoint.json'],
  [join(ROOT, 'corpus', 'binding', 'stories.json'), 'binding-stories.json'],
  [join(ROOT, 'corpus', 'binding', 'challenges.json'), 'binding-challenges.json'],
  [join(ROOT, 'models', 'stories260K-binding.bin'), 'stories260K-binding.bin'],
];
const results = [];
for (const [path, name] of resultFiles) results.push({ name, data: new Uint8Array(await readFile(path)) });
const resultsZip = makeZip(results);
await writeFile(join(dist, 'binding-results.zip'), resultsZip);
console.log(`dist/binding-results.zip: ${(resultsZip.length / 1e6).toFixed(1)} MB`);
