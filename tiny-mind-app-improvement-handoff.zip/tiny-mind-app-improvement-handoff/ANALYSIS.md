# Analysis of the balanced-character binding arc

## Executive conclusion

The automatic selector chose step 60 because it imposed a hard ordinary-story-loss ceiling of +0.15 nats. That checkpoint does **not** demonstrate the intended phenomenon: direct accuracy is 25%, name specificity is 33.3%, and its mean leakage ratio is above 1.0. It should not be shipped as the binding model.

Use **step 400** as the default demonstration checkpoint. Keep **step 600** as the end of the time-machine arc and label it “maximum binding / more rigid and forgetful.” Step 60 is useful pedagogically as “held-out loss looks best before the model has actually separated the characters.”

## Checkpoint table

| step | held loss | base loss | Δ base | direct | specificity | paraphrase | distractor | override | leak ratio | binding score | repetition |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 2.1568 | 1.4693 | 0.0000 | 25.0% | 33.3% | 16.7% | 25.0% | 0.0% | 1.0331 | 0.2500 | 15.8% |
| 10 | 1.6817 | 1.5558 | 0.0865 | 25.0% | 16.7% | 16.7% | 25.0% | 0.0% | 1.0525 | 0.2083 | 21.4% |
| 20 | 1.6057 | 1.5799 | 0.1106 | 25.0% | 16.7% | 25.0% | 25.0% | 0.0% | 1.0320 | 0.2292 | 24.9% |
| 40 | 1.5620 | 1.6305 | 0.1612 | 25.0% | 16.7% | 25.0% | 25.0% | 0.0% | 1.0310 | 0.2292 | 38.0% |
| 60 | 1.5475 | 1.6158 | 0.1465 | 25.0% | 33.3% | 25.0% | 25.0% | 0.0% | 1.0214 | 0.2708 | 37.6% |
| 80 | 1.5705 | 1.6272 | 0.1579 | 33.3% | 33.3% | 25.0% | 33.3% | 0.0% | 1.0120 | 0.3125 | 45.9% |
| 120 | 1.5659 | 1.6903 | 0.2210 | 33.3% | 50.0% | 25.0% | 50.0% | 0.0% | 0.9751 | 0.3958 | 22.3% |
| 160 | 1.5678 | 1.6927 | 0.2234 | 33.3% | 58.3% | 50.0% | 66.7% | 0.0% | 0.9059 | 0.5208 | 32.9% |
| 240 | 1.5976 | 1.7444 | 0.2751 | 66.7% | 91.7% | 83.3% | 91.7% | 0.0% | 0.7815 | 0.8333 | 33.3% |
| 400 | 1.6788 | 1.8478 | 0.3785 | 83.3% | 100.0% | 91.7% | 100.0% | 0.0% | 0.5876 | 0.9375 | 15.5% |
| 600 | 1.8116 | 1.9435 | 0.4742 | 91.7% | 100.0% | 100.0% | 100.0% | 0.0% | 0.5632 | 0.9792 | 4.6% |

## What the arc teaches

1. **Loss improvement is not the same as relational learning.** Held-out story loss bottoms out at step 60, while direct and specificity tests remain near chance.
2. **Binding emerges late and abruptly.** Specificity rises from 58.3% at step 160 to 91.7% at step 240.
3. **There is a real trade-off.** By step 400 the model has strong binding, but ordinary-story loss has risen by 0.3785 nats.
4. **The model is rigid rather than context-sensitive.** Override accuracy is 0% at every checkpoint and the learned defaults dominate more strongly late in training.
5. **The current repetition metric is insufficient.** Step 600 scores only 4.6% repeated four-grams, yet samples contain malformed names, cross-character intrusion, and semantic breakdown. Add character consistency and language-quality checks.

## Recommended app narrative

- **Steps 0–80:** “The model is learning the new story world, but it mixes the characters together.”
- **Steps 120–160:** “The names are beginning to matter.”
- **Step 240:** “Character-specific facts emerge.”
- **Step 400:** “Strong binding, with noticeable forgetting. Recommended investigation point.”
- **Step 600:** “Maximum measured binding, but more rigid and less reliable as a storyteller.”

## Important checkpoint-specific failures

- Step 400 misses Zog→clouds in a four-way value comparison and Nia→tree in direct/paraphrase comparison, but all 12 facts are name-specific and all distractor tests pass.
- Step 600 misses only Zog→clouds in direct value comparison; all specificity, paraphrase, and distractor tests pass.
- No checkpoint follows the temporary food override. This should be displayed as a separate “flexibility” limitation, not folded into the binding score.