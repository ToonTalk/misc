// select-binding-profiles.js
// Usage: node tools/select-binding-profiles.js path/to/binding-evaluation.json [out.json]
import { readFile, writeFile } from 'node:fs/promises';

const [input = 'binding-results/binding-evaluation.json', output = 'binding-profiles.json'] = process.argv.slice(2);
const data = JSON.parse(await readFile(input, 'utf8'));
const rows = data.checkpoints;
const nonzero = rows.filter(r => r.step !== 0);
const byMin = (key) => nonzero.reduce((a,b) => b[key] < a[key] ? b : a);
const byMaxSummary = (key) => nonzero.reduce((a,b) => b.summary[key] > a.summary[key] ? b : a);
const ready = nonzero.filter(r =>
  r.summary.directAccuracy >= 0.75 &&
  r.summary.specificityAccuracy >= 0.90 &&
  r.summary.paraphraseAccuracy >= 0.75 &&
  r.summary.distractorAccuracy >= 0.90);
const demo = ready.sort((a,b) => a.step - b.step)[0] ?? byMaxSummary('bindingScore');
const held = byMin('bindingHeld');
const max = byMaxSummary('bindingScore');
const pick = r => ({ step:r.step, file:r.file, bindingHeld:r.bindingHeld, baseLoss:r.baseLoss,
  repetitionRate:r.repetitionRate, summary:r.summary });
const result = {
  note: 'Different educational goals require different checkpoints; there is no single scalar optimum.',
  heldLossMinimum: pick(held),
  bindingDemonstration: pick(demo),
  maximumBinding: pick(max),
};
await writeFile(output, JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
