# Corrected binding models

- `stories260K-binding.bin`: **step 400**, recommended for the default Treasure Hunt demonstration. Strong name specificity and distractor performance with less degradation than step 600.
- `stories260K-binding-max.bin`: **step 600**, maximum measured binding; use as the final time-machine stage.
- The prior `stories260K-binding.bin` from Codex's original results was step 60 and should not be used as the binding demonstration model.
