// Full post-training evaluation for the balanced character-binding experiment.
//
// Usage:
//   node tools/evaluate-binding.js --arc=arc/binding
//   node tools/evaluate-binding.js models/stories260K.bin models/another.bin
//
// Arc mode evaluates every snapshot, writes JSON + Markdown, and copies the selected
// checkpoint to models/stories260K-binding.bin (use --no-copy to suppress the copy).
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { join, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCheckpoint } from '../src/bin-reader.js';
import { Tokenizer } from '../src/tokenizer.js';
import { evaluateBindingModel, compactBindingSummary } from './binding-eval-lib.js';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const args = process.argv.slice(2);
const arcArg = args.find(a => a.startsWith('--arc='));
const outArg = args.find(a => a.startsWith('--out='));
const noCopy = args.includes('--no-copy');
const positional = args.filter(a => !a.startsWith('--'));
const challenges = JSON.parse(await readFile(join(ROOT, 'corpus', 'binding', 'challenges.json'), 'utf8'));
const baseCk = readCheckpoint(await readFile(join(ROOT, 'models', 'stories260K.bin')));
const tok = new Tokenizer(await readFile(join(ROOT, 'models', 'tok512.bin')), baseCk.config.vocabSize);

function pct(x) { return `${(100 * x).toFixed(1)}%`; }
function n4(x) { return Number.isFinite(x) ? x.toFixed(4) : '—'; }
function average(xs) { return xs.reduce((a, b) => a + b, 0) / Math.max(1, xs.length); }

async function evaluateFile(path, meta = {}) {
  console.log(`evaluating ${path}`);
  const checkpoint = readCheckpoint(await readFile(path));
  const result = evaluateBindingModel(checkpoint, tok, challenges, { mode: 'full', samples: true });
  const repetitionRate = average(Object.values(result.samples).map(s => s.repetitionRate));
  return {
    ...meta,
    path,
    file: basename(path),
    summary: compactBindingSummary(result),
    repetitionRate,
    details: result,
  };
}

function selectRecommended(rows) {
  const baseRow = rows.find(r => r.step === 0);
  const baseLoss0 = baseRow?.baseLoss;
  let candidates = rows.filter(r => r.step !== 0);
  if (Number.isFinite(baseLoss0)) {
    const restrained = candidates.filter(r => !Number.isFinite(r.baseLoss) || r.baseLoss <= baseLoss0 + 0.15);
    if (restrained.length) candidates = restrained;
  }
  if (!candidates.length) candidates = rows;
  candidates.sort((a, b) => {
    const ds = b.summary.bindingScore - a.summary.bindingScore;
    if (Math.abs(ds) > 0.01) return ds;
    const spec = b.summary.specificityAccuracy - a.summary.specificityAccuracy;
    if (Math.abs(spec) > 0.01) return spec;
    const rep = a.repetitionRate - b.repetitionRate;
    if (Math.abs(rep) > 0.005) return rep;
    return (a.step ?? 0) - (b.step ?? 0);
  });
  return candidates[0];
}

function failureLines(result, section, limit = 12) {
  const rows = result.details[section]?.rows ?? [];
  return rows.filter(r => !r.correct).slice(0, limit).map(r => {
    if (r.candidates) return `- ${r.id}: expected **${r.expected}**, top answer was **${r.candidates[0]?.value}**.`;
    if (r.scores) return `- ${r.id}: target **${r.target}** was more strongly associated with **${r.scores[0]?.name}** than ${r.expectedName}.`;
    return `- ${r.id}`;
  });
}

function makeMarkdown(rows, recommended, modeLabel) {
  const lines = [];
  lines.push('# Tiny Mind balanced character-binding evaluation', '');
  lines.push(`Evaluated ${rows.length} checkpoint(s) from ${modeLabel}.`);
  if (recommended) lines.push(`Recommended checkpoint: **${recommended.file}**${recommended.step === undefined ? '' : ` at step ${recommended.step}`}.`);
  lines.push('');
  lines.push('| step/model | held loss | base loss | direct | name specificity | paraphrase | distractor | override | leak ratio | repetition | score |');
  lines.push('|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|');
  for (const r of rows) {
    const s = r.summary;
    lines.push(`| ${r.step ?? r.file} | ${n4(r.bindingHeld)} | ${n4(r.baseLoss)} | ${pct(s.directAccuracy)} | ${pct(s.specificityAccuracy)} | ${pct(s.paraphraseAccuracy)} | ${pct(s.distractorAccuracy)} | ${pct(s.overrideAccuracy)} | ${n4(s.meanLeakageRatio)} | ${pct(r.repetitionRate)} | ${n4(s.bindingScore)} |`);
  }
  if (recommended) {
    lines.push('', '## Recommendation', '');
    lines.push('Use `' + recommended.path + '` as the first model to inspect in Tiny Mind.');
    lines.push('Selection maximizes the combined direct, specificity, paraphrase, and distractor score while preferring checkpoints with limited ordinary-story loss and less repetition.');
    lines.push('', '### Remaining direct-answer failures', '');
    lines.push(...(failureLines(recommended, 'direct').length ? failureLines(recommended, 'direct') : ['None.']));
    lines.push('', '### Remaining name-specificity failures', '');
    lines.push(...(failureLines(recommended, 'specificity').length ? failureLines(recommended, 'specificity') : ['None.']));
    lines.push('', '### Generated samples', '');
    for (const [name, sample] of Object.entries(recommended.details.samples)) {
      lines.push(`**${name}:** ${sample.text.replace(/\s+/g, ' ').trim()}`, '');
    }
  }
  lines.push('## Interpretation cautions', '');
  lines.push('- Direct accuracy asks whether the correct attribute beats the other three attributes.');
  lines.push('- Name specificity asks whether a target fact scores highest under its correct name rather than another name.');
  lines.push('- Override accuracy is deliberately difficult: it tests whether immediate context can overcome the learned default.');
  lines.push('- These behavioural tests do not by themselves locate where a fact is stored.');
  return lines.join('\n');
}

let rows = [];
let outputDir;
let modeLabel;
if (arcArg) {
  const arcRel = arcArg.slice(6);
  const arcDir = join(ROOT, arcRel);
  const manifest = JSON.parse(await readFile(join(arcDir, 'arc-manifest.json'), 'utf8'));
  outputDir = outArg ? join(ROOT, outArg.slice(6)) : arcDir;
  modeLabel = arcRel;
  for (const s of manifest.snapshots) {
    rows.push(await evaluateFile(join(arcDir, s.file), {
      step: s.step,
      bindingHeld: s.bindingHeld,
      baseLoss: s.baseLoss,
      trainLoss: s.trainLoss,
      manifestBinding: s.binding,
    }));
  }
} else {
  const files = positional.length ? positional : ['models/stories260K.bin'];
  outputDir = outArg ? join(ROOT, outArg.slice(6)) : join(ROOT, 'binding-evaluation');
  modeLabel = files.join(', ');
  for (const f of files) rows.push(await evaluateFile(join(ROOT, f)));
}

await mkdir(outputDir, { recursive: true });
const recommended = selectRecommended([...rows]);
const output = {
  generatedAt: new Date().toISOString(),
  mode: modeLabel,
  challengeFile: 'corpus/binding/challenges.json',
  recommendation: recommended ? {
    step: recommended.step, file: recommended.file, path: recommended.path,
    summary: recommended.summary, repetitionRate: recommended.repetitionRate,
  } : null,
  checkpoints: rows,
};
await writeFile(join(outputDir, 'binding-evaluation.json'), JSON.stringify(output, null, 2));
await writeFile(join(outputDir, 'binding-evaluation.md'), makeMarkdown(rows, recommended, modeLabel));
if (recommended) {
  await writeFile(join(outputDir, 'recommended-checkpoint.json'), JSON.stringify(output.recommendation, null, 2));
  if (!noCopy && arcArg) {
    const dest = join(ROOT, 'models', 'stories260K-binding.bin');
    await copyFile(recommended.path, dest);
    console.log(`copied recommended checkpoint to ${dest}`);
  }
}
console.log(`wrote ${join(outputDir, 'binding-evaluation.json')}`);
console.log(`wrote ${join(outputDir, 'binding-evaluation.md')}`);
