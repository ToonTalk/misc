// Suggested metric-derived stage helper for src/scrubber.js
export function bindingStage(snapshot, baseLoss0 = null) {
  const b = snapshot && snapshot.binding;
  if (!b) return null;
  const direct = b.directAccuracy ?? 0;
  const spec = b.specificityAccuracy ?? 0;
  let label;
  if (spec >= 0.95 && direct >= 0.8) label = 'strong character binding';
  else if (spec >= 0.8 && direct >= 0.6) label = 'character facts separating';
  else if (spec >= 0.5) label = 'names beginning to matter';
  else label = 'mixing the characters';
  const forgetting = Number.isFinite(baseLoss0) && Number.isFinite(snapshot.baseLoss)
    ? snapshot.baseLoss - baseLoss0 : null;
  return { label, forgetting, warnForgetting: forgetting !== null && forgetting >= 0.25 };
}
