# Codex task: run the Tiny Mind balanced character-binding experiment

## Goal

Train a new Tiny Mind arc that tests whether the 260K model can bind different facts to different names, rather than learning one global story pattern. Do **not** redesign the app yet. Produce the model, arc, measurements, and logs so Ken can bring them back to the original ChatGPT conversation for interpretation and app planning.

The four equally frequent characters are:

| Name | Kind | Food | Home word |
|---|---|---|---|
| Zog | small dragon | clouds | moon |
| Mip | small rabbit | apples | river |
| Bex | small bear | honey | cave |
| Nia | small bird | berries | tree |

Every training character appears equally often. Single-character stories are supplemented by paired contrast stories and four-character stories. Exact matched fact frames make controlled one-token comparisons possible, while the surrounding narratives vary.

## Install the handoff

Copy the contents of this bundle into the Tiny Mind repository root, preserving paths:

- `corpus/binding/stories.json`
- `corpus/binding/challenges.json`
- `tools/gen-binding-corpus.js`
- `tools/binding-eval-lib.js`
- `tools/make-binding-arc.js`
- `tools/evaluate-binding.js`
- `tools/make-binding-arc-zip.js`
- `tools/run-binding-experiment.js`

These files are additive. Do not replace the existing Zog corpus or its arc scripts.

The scripts expect these existing repository resources:

- `models/stories260K.bin`
- `models/tok512.bin`
- `corpus/replay/replay.json`
- `src/bin-reader.js`
- `src/tokenizer.js`
- `src/model.js`
- `src/train.js`
- `tools/zip.js`

## Preflight

From the repository root:

```bash
node --version
node --check tools/gen-binding-corpus.js
node --check tools/binding-eval-lib.js
node --check tools/make-binding-arc.js
node --check tools/evaluate-binding.js
node --check tools/make-binding-arc-zip.js
node tools/gen-binding-corpus.js
```

The validator should report **64 train + 16 heldout** and equal training appearances for all four characters. It may report optional word-list warnings. Those warnings are diagnostic and should not block the run unless they reveal genuinely unsuitable words.

## Run the experiment

Preferred one-command route:

```bash
node tools/run-binding-experiment.js
```

If interrupted after at least one saved snapshot:

```bash
node tools/run-binding-experiment.js --resume
```

For a short pipeline check before the full run:

```bash
node tools/run-binding-experiment.js --max-step=40 --out=arc/binding-probe
```

The full default run saves snapshots at steps:

```text
0, 10, 20, 40, 60, 80, 120, 160, 240, 400, 600
```

Default recipe:

```text
B=8, T=192, learning rate=3e-4, replay=50%, seed=17
```

Do not silently change the corpus, recipe, or metrics. A code compatibility fix is fine; record it in `CODEX_CHANGES.md`.

## What the evaluation measures

For every checkpoint, the evaluator records:

1. **Direct accuracy** — does the correct kind, food, or home beat the other three candidates?
2. **Name specificity** — does a fact score highest with its correct name rather than another name?
3. **Paraphrase accuracy** — does the same binding survive a question-like reformulation?
4. **Distractor accuracy** — can the model retrieve the requested character after all four fact sets appear in context?
5. **Override accuracy** — can immediate contradictory context overcome the learned default?
6. **Ordinary-story loss** — how much general TinyStories ability was lost?
7. **Repetition rate** — do generated samples fall into repeated four-word loops?

The evaluator selects a recommended snapshot by combining the first four behavioural measures, while preferring limited ordinary-story loss and lower repetition. Preserve all snapshots even if the selected checkpoint is early.

## Required outputs

The scripts should produce:

```text
arc/binding/arc-manifest.json
arc/binding/binding-evaluation.json
arc/binding/binding-evaluation.md
arc/binding/recommended-checkpoint.json
arc/binding/codex-run-log.json
models/stories260K-binding.bin
dist/binding-arc.zip
dist/binding-results.zip
```

`binding-arc.zip` is the flat arc pack for Tiny Mind. `binding-results.zip` is the compact return package containing the recommended model, manifest, corpus metadata, and full evaluation.

## Browser smoke test

After training, run the existing local server:

```bash
node tools/serve.js
```

Open the Tiny Mind mega app through that server and check:

1. `dist/binding-arc.zip` is accepted as an arc pack.
2. The time-machine slider lists every snapshot.
3. Stored samples can be viewed at several points.
4. `models/stories260K-binding.bin` loads with `models/tok512.bin` in the Microscope and Hunt.
5. No console errors occur.

The current UI may not display the new `bindingHeld` and `binding` manifest fields. That is expected. Do not redesign those views in this task; simply record what the current UI ignores.

## Return to Ken's ChatGPT conversation

Upload these two files there:

- `dist/binding-results.zip`
- `dist/binding-arc.zip`

Also report:

- whether any script was changed for repository compatibility;
- whether the arc loaded in the browser;
- any console error;
- the recommended step and its short metric row.

The next phase will use those outputs to decide how to change the Nursery, time machine, evaluation panel, quick quests, and Treasure Hunt language.
