# User-facing copy replacements

| Current | Replace with |
|---|---|
| `PROVED` | `STRONG CAUSAL EFFECT` |
| `the treasure really is (partly) here` | `this part contributed strongly to this prediction` |
| `You PROVED where the treasure is!` | `You found strong causal evidence. Now check whether it is selective.` |
| `there is no character-treasure to hunt` | `this prediction is not name-specific yet; the model may be following a general phrase pattern` |
| `where does it keep what it knows?` | `which parts contribute when it uses what it learned?` |
| `your character lives somewhere inside those numbers. find it. prove it.` | `the model changed inside. Find parts that contribute, and test whether their effects are specific.` |
