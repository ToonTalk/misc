# Why this corpus is different from the original Zog corpus

The original corpus made Zog, clouds, moon, and dragon co-occur in every story. A model could lower its loss by making those words globally likely in the new story domain, without using the name Zog to select among competing facts.

This corpus changes the identifiability of the task:

- Four names occur equally often.
- Each slot has four incompatible values.
- Canonical fact sentences use matched syntax across names.
- Paired stories put two complete fact sets in the same local context.
- Group stories require four-way separation.
- Held-out stories use new events while preserving the underlying bindings.
- Evaluation compares the correct value against all alternatives and substitutes other names into the same prompt frame.

A successful model therefore cannot get full credit merely by making `moon`, `clouds`, and `dragon` globally common. It must make the answer depend on the name.

The corpus still does not prove symbolic variable binding. It tests a concrete behavioural criterion: whether changing the name changes which learned attribute the model predicts.
