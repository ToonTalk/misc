# ToonTalk Web — Claude Code kit

Drop-in additions for the `toontalk-web/` repo to make Claude Code sessions
faster and more reliable. Three pieces, each independent:

## 1. `tools/verify/` — deterministic visual verification (the big one)

Your CLAUDE.md mentions the preview-screenshot problem four separate times:
the preview tab is backgrounded (rAF + PIXI ticker paused), so the city,
sensors, and houses never advance, and animated scenes time out the
screenshot tool. Opus has been working around it with `ticker.stop()` tricks
and "verify in a real browser".

`snap.mjs` fixes it properly: headless Chromium (page counts as visible) plus
a **manually pumped ticker** (`__ttApp.ticker.update(t)` in simulated-time
steps), so any frame of any animation is capturable, deterministically and
repeatably. It also supports shot *series* (frame-by-frame animation review),
scripted key presses (fly/land in the city), and `--eval` snippets that
return JSON from the page (`__ttWorld` summaries, sensor values, etc.).

Setup:

```bash
npm i -D playwright
npx playwright install chromium
```

## 2. `.claude/skills/` — three skills

- **verify-app** — teaches Claude to reach for the harness instead of the
  flaky preview tool, with worked examples.
- **new-element** — the faithful-scaffold checklist (manual page → original
  C++ → model → interactions → persistence → view → seed → tests → visual
  check → ledger update). Invoke as `/new-element` or let Claude trigger it.
- **fidelity-audit** — `/fidelity-audit boxes` produces a
  manual-vs-C++-vs-ours divergence table and updates the ledger.

(On older Claude Code versions without skills, these also work flattened into
`.claude/commands/<name>.md`.)

## 3. `CLAUDE.suggested.md` + `docs/` — a leaner project memory

Your CLAUDE.md is 361 lines and growing with every feature; all of it is
loaded into context at the start of every session, and per-feature detail
buries the rules that matter every turn. The restructure:

- `CLAUDE.md` (≈110 lines): guiding principle, working facts, architecture,
  a compact **element status table**, verification rules — only what's needed
  every session, plus pointers.
- `docs/elements.md`: the full per-element digest — now the designated
  "fidelity ledger" that grows instead of CLAUDE.md.
- `docs/assets.md`, `docs/room-city.md`: art pipeline and shell/city detail,
  read on demand.

To adopt: copy `docs/` in, then replace `CLAUDE.md` with
`CLAUDE.suggested.md` (renamed). Content is your original text reorganized —
nothing was dropped, but worth a skim to confirm. If you'd rather not switch,
the harness and skills work fine with your current CLAUDE.md.

## Install

Copy everything except this README and `CLAUDE.suggested.md` into
`toontalk-web/` (the `.claude/`, `tools/`, and `docs/` trees merge with what's
there). Add `tools/verify/shots/` to `.gitignore`. Then in a Claude Code
session: "Read tools/verify/README.md and try a room screenshot" to confirm
the harness works — two small things may need a one-line fix against the real
app: the city-visibility probe in `--scene` (it guesses at `__ttCity`'s
shape) and the `world-summary.js` example (adapt to `World`'s actual API).

## Possible next steps (not included)

- A `PostToolUse` hook running `npm run typecheck` after edits, so type
  errors surface immediately instead of at commit time (can be slow on every
  edit — try it before keeping it).
- A CI job (or pre-commit) that runs typecheck + vitest + a couple of `snap`
  reference shots, diffing them against checked-in goldens — cheap visual
  regression for the faithful render mode.
- A `bake-asset` skill wrapping `parse-tts.py`/`bake-city.py` conventions, if
  asset conversion keeps recurring.
